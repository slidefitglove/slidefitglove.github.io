#ifndef __MOTOR_H
#define __MOTOR_H

#include "sys.h"

#define MOTOR_COUNT 5U
#define MOTOR_RATED_DUTY_PERCENT 40U

void Motor_Init(void);
void Motor_SetDuty(u8 motor_number, u8 duty_percent);
void Motor_AllSetDuty(u8 duty_percent);

#endif
