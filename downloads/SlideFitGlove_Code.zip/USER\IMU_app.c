#include <stdbool.h>
#include <string.h>
#include "sys.h"
#include "delay.h"
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h" 
#include "usart.h"
#include "led.h"
#include "IMU_app.h"
#include "UART_app.h"

u32 pitchAngle = 0;//�������м����
u32 rollAngle  = 0;//������м����
u32 tiltAngle  = 0;//��б���м����
u16 calFrequency  = 0;//��������

bool imuAttitudeFlag = false;//IMUλ�������־

float pitch = 0;
float roll  = 0;
float tilt  = 0;

int pitchsignBit = 0;
int rollsignBit  = 0;
int tiltsignBit  = 0;

u8 sensorSet[12] = {0x7a, 0x7b, 0x0a, 0xb2, 0x00, 0x02};

char *pitch1 = "pitch\n";
char *roll1 = "roll\n";
char *tilt1 = "tilt\n";

void IMU_APP(void)
{
		if(imuAttitudeFlag == true)
		{
			pitchAngle = IMU_RX_BUF_U2[4]  << 16 | IMU_RX_BUF_U2[5] << 8 | IMU_RX_BUF_U2[6];//������
			rollAngle  = IMU_RX_BUF_U2[7]  << 16 | IMU_RX_BUF_U2[8] << 8 | IMU_RX_BUF_U2[9];//�����
			tiltAngle  = IMU_RX_BUF_U2[10] << 16 | IMU_RX_BUF_U2[11] << 8 | IMU_RX_BUF_U2[12];//��б��
			calFrequency  = IMU_RX_BUF_U2[13] << 8 | IMU_RX_BUF_U2[14];//��������
			
			if((pitchAngle & 0x00800000) == 0)//����λ�жϣ�0����1�Ǹ�
			{
				pitchsignBit = 1;
			}
			else
				pitchsignBit = -1;		
			pitch = pitchsignBit * (int)(pitchAngle & 0x007fffff) * 0.0001f;//ʵ�ʸ�����
			printf("\npitch:%.4f��\n", pitch);
			//UartSendDat(USART1, (u8 *)pitch1, strlen(pitch1));
			
			if((rollAngle & 0x00800000) == 0)//����λ�жϣ�0����1�Ǹ�
			{
				rollsignBit = 1;
			}
			else
				rollsignBit = -1;		
			roll = rollsignBit * (int)(rollAngle & 0x007fffff) * 0.0001f;//ʵ�ʺ����
			printf("\nroll:%.4f��\n", roll);
			//UartSendDat(USART1, (u8 *)roll1, strlen(roll1));
			if(roll > 360.0f)
				printf("16���ƣ�%x\n",rollAngle);
			
			if((tiltAngle & 0x00800000) == 0)//����λ�жϣ�0����1�Ǹ�
			{
				tiltsignBit = 1;
			}
			else
				tiltsignBit = -1;		
			tilt = tiltsignBit * (int)(tiltAngle & 0x007fffff) * 0.0001f;//ʵ����б��
			printf("\nyaw:%.4f��\n", tilt);
			//UartSendDat(USART1, (u8 *)tilt1, strlen(tilt1));
			
			imuAttitudeFlag = false;
			imu_len = 0;
			memset(IMU_RX_BUF_U2, 0, 204);
		}
}

void IMU_initSet(dataType type, u8 speed, u32 bound)
{
		switch (type)
		{
			case originalADC:
				sensorSet[6] = originalADC;
				break;
			case calculatingAngle:
				sensorSet[6] = calculatingAngle;
				break;
			case bothData:
				sensorSet[6] = bothData;
				break;
			default:
				break;
		}
		switch (speed)
		{
			case 10:
				sensorSet[7] = frame_10;
				break;
			case 20:
				sensorSet[7] = frame_20;
				break;
			case 50:
				sensorSet[7] = frame_50;
				break;
			case 70:
				sensorSet[7] = frame_70;
				break;
			case 100:
				sensorSet[7] = frame_100;
				break;
			default:
				break;
		}
		switch (bound)
		{
			case 2400:
				sensorSet[9] = bound2400;
				break;
			case 4800:
				sensorSet[9] = bound4800;
				break;
			case 9600:
				sensorSet[9] = bound9600;
				break;
			case 14400:
				sensorSet[9] = bound14400;
				break;
			case 19200:
				sensorSet[9] = bound19200;
				break;
			case 38400:
				sensorSet[9] = bound38400;
				break;
			case 56000:
				sensorSet[9] = bound56000;
				break;
			case 115200:
				sensorSet[9] = bound115200;
				break;
			default:
				break;
		}
		sensorSet[8]  = 0x00;//����ͨ��
		sensorSet[10] = sensorSet[2] ^ sensorSet[3] ^ sensorSet[4] ^ sensorSet[5] ^ sensorSet[6] ^ sensorSet[7] ^ sensorSet[8] ^ sensorSet[9];
		sensorSet[11] = 0xbb;
		delay_ms(10);
		UartSendDat(USART2, sensorSet, 12);
		printf("IMU INIT DONE!\n");
}
