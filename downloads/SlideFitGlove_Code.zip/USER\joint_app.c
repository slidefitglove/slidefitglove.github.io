#include <stdio.h>
#include <stdbool.h>
#include "sys.h"
#include "adc.h"
#include "FreeRTOS.h"
#include "task.h"
#include "joint_app.h"

#define AVERAGE_SAMPLES       32U
#define POSITION_FILTER_ALPHA 0.25f
#define CONTINUOUS_STREAM_PERIOD_MS 50U

/*
 * User assignment:
 * tactile: logical ADC12,17,18,19,20,21,22,23,24,29,30
 *          (ADC19/CN24 and ADC20/CN25 are no longer used for posture)
 *          Middle/ring side swing moved to ADC31/CN37 and ADC32/CN38.
 * posture: calibrated serial order: index, middle, ring, little finger, thumb.
 */
static const u8 posture_adc_number[POSTURE_CHANNEL_COUNT] =
{
    13,  9, 14, 16,
     1,  5, 10, 31,
    28,  4,  3, 32,
    26, 25, 27, 11,
     8,  2,  6,  7, 15
};

/* Reference angle, ADC at that angle, and calibrated mechanical zero ADC. */
static const float posture_reference_angle[POSTURE_CHANNEL_COUNT] =
{
    90.0f, 90.0f, 90.0f, 30.0f,
    90.0f, 90.0f, 90.0f, 30.0f,
    90.0f, 90.0f, 90.0f, 30.0f,
    90.0f, 90.0f, 90.0f, 30.0f,
    90.0f, 90.0f, 90.0f, 90.0f, 30.0f
};

static const u16 posture_reference_adc[POSTURE_CHANNEL_COUNT] =
{
     960,  934,  913, 2450,
     977,  971,  971, 2450,
     977,  971,  971, 2450,
     977,  971,  971, 2351,
     900,  900,  900, 2080, 3157
};

static const u16 posture_calibrated_zero_adc[POSTURE_CHANNEL_COUNT] =
{
    2100, 2026, 2058, 2033,
    2069, 2045, 2045, 2033,
    2069, 2045, 2045, 2033,
    2069, 2045, 2045, 2088,
    2020, 1790, 2000, 3200, 2030
};

/* Side-swing channels and thumb joint 3 (ADC6) are signed. */
static const u8 posture_is_signed[POSTURE_CHANNEL_COUNT] =
{
    0, 0, 0, 1,
    0, 0, 0, 1,
    0, 0, 0, 1,
    0, 0, 0, 1,
    0, 0, 1, 0, 1
};


static const u8 tactile_adc_number[TACTILE_CHANNEL_COUNT] =
{
    12, 17, 18, 19, 20, 21, 22, 23, 24, 29, 30
};

static bool angle_snapshot_requested = false;
static bool tactile_stream_enabled = false;
static bool raw_stream_enabled = false;
static bool average_snapshot_requested = false;
static bool mapping_requested = false;
static bool wearing_zero_requested = false;
static bool wearing_zero_valid = false;
static bool continuous_stream_immediate = false;
static TickType_t last_continuous_stream_tick = 0U;

static u16 wearing_zero[POSTURE_CHANNEL_COUNT];
static float filtered_posture[POSTURE_CHANNEL_COUNT];
static bool filter_initialized = false;

static void PrintU16Frame(const char *name, const u16 *values, u8 count)
{
    u8 index;

    printf("%s", name);
    for(index = 0; index < count; index++)
    {
        printf(",%u", (unsigned int)values[index]);
    }
    printf("\r\n");
}

static void ExtractChannels(const u16 all_adc[ADC_LOGICAL_CHANNEL_COUNT],
                            const u8 *adc_numbers, u8 count, u16 *output)
{
    u8 index;

    for(index = 0; index < count; index++)
    {
        output[index] = all_adc[adc_numbers[index] - 1U];
    }
}

/* Integer formatting is much faster than 21 separate printf("%.2f") calls. */
static void PrintAngleValue(float angle)
{
    s32 hundredths;
    u32 magnitude;

    if(angle >= 0.0f)
        hundredths = (s32)(angle * 100.0f + 0.5f);
    else
        hundredths = (s32)(angle * 100.0f - 0.5f);

    if(hundredths < 0)
    {
        magnitude = (u32)(-hundredths);
        printf(",-%lu.%02lu", (unsigned long)(magnitude / 100U),
               (unsigned long)(magnitude % 100U));
    }
    else
    {
        magnitude = (u32)hundredths;
        printf(",%lu.%02lu", (unsigned long)(magnitude / 100U),
               (unsigned long)(magnitude % 100U));
    }
}

static void PrintAngleFrame(const u16 all_adc[ADC_LOGICAL_CHANNEL_COUNT])
{
    u8 index;
    float zero_adc;
    float denominator;
    float angle;

    printf("ANG");

    /*
     * Calibration-table zero ADC values define slope only. Mechanical fit and
     * the wearer's hand define the real zero, so no angle is calculated until
     * WZER has captured the current 21-channel pose.
     */
    if(!wearing_zero_valid)
    {
        for(index = 0; index < POSTURE_CHANNEL_COUNT; index++)
        {
            printf(",0.00");
        }
        printf("\r\n");
        return;
    }

    for(index = 0; index < POSTURE_CHANNEL_COUNT; index++)
    {
        u16 raw = all_adc[posture_adc_number[index] - 1U];

        /* ADC timeout or a hard rail reading is reported as an invalid input. */
        if(raw <= 4U || raw >= 4091U)
        {
            filtered_posture[index] = 0.0f;
            printf(",0.00");
            continue;
        }

        if(!filter_initialized)
        {
            filtered_posture[index] = (float)raw;
        }
        else
        {
            filtered_posture[index] += POSITION_FILTER_ALPHA *
                                      ((float)raw - filtered_posture[index]);
        }

        zero_adc = (float)wearing_zero[index];

        if(posture_is_signed[index] != 0U)
        {
            denominator = (float)posture_reference_adc[index] -
                          (float)posture_calibrated_zero_adc[index];
            if(denominator < 0.0f) denominator = -denominator;
            angle = (filtered_posture[index] - zero_adc) *
                    posture_reference_angle[index] / denominator;
            if(angle > posture_reference_angle[index])
                angle = posture_reference_angle[index];
            if(angle < -posture_reference_angle[index])
                angle = -posture_reference_angle[index];
        }
        else
        {
            denominator = (float)posture_calibrated_zero_adc[index] -
                          (float)posture_reference_adc[index];
            if(denominator < 0.0f) denominator = -denominator;
            angle = filtered_posture[index] - zero_adc;
            if(angle < 0.0f) angle = -angle;
            angle = angle * posture_reference_angle[index] / denominator;
            if(angle > posture_reference_angle[index])
                angle = posture_reference_angle[index];
        }
        PrintAngleValue(angle);
    }
    printf("\r\n");
    filter_initialized = true;
}

static void CaptureWearingZero(const u16 all_adc[ADC_LOGICAL_CHANNEL_COUNT])
{
    u8 index;

    for(index = 0; index < POSTURE_CHANNEL_COUNT; index++)
    {
        wearing_zero[index] = all_adc[posture_adc_number[index] - 1U];
        filtered_posture[index] = (float)wearing_zero[index];
    }
    wearing_zero_valid = true;
    filter_initialized = true;
    PrintU16Frame("WZERO", wearing_zero, POSTURE_CHANNEL_COUNT);
}

static void PrintAverageSnapshot(void)
{
    u32 sums[ADC_LOGICAL_CHANNEL_COUNT] = {0};
    u16 values[ADC_LOGICAL_CHANNEL_COUNT];
    u16 average[ADC_LOGICAL_CHANNEL_COUNT];
    u8 sample;
    u8 channel;

    for(sample = 0; sample < AVERAGE_SAMPLES; sample++)
    {
        ADC_ReadAll32(values);
        for(channel = 0; channel < ADC_LOGICAL_CHANNEL_COUNT; channel++)
        {
            sums[channel] += values[channel];
        }
    }

    for(channel = 0; channel < ADC_LOGICAL_CHANNEL_COUNT; channel++)
    {
        average[channel] = (u16)(sums[channel] / AVERAGE_SAMPLES);
    }
    PrintU16Frame("AVG", average, ADC_LOGICAL_CHANNEL_COUNT);
}

static void PrintMapping(void)
{
    u8 index;

    printf("MAP,POSTURE");
    for(index = 0; index < POSTURE_CHANNEL_COUNT; index++)
    {
        printf(",ADC%u", (unsigned int)posture_adc_number[index]);
    }
    printf("\r\nMAP,TACTILE");
    for(index = 0; index < TACTILE_CHANNEL_COUNT; index++)
    {
        printf(",ADC%u", (unsigned int)tactile_adc_number[index]);
    }
    printf("\r\n");
}

void Joint_RequestCalibrationStreamStart(void)
{
    raw_stream_enabled = true;
    continuous_stream_immediate = true;
}

void Joint_RequestCalibrationStreamStop(void)
{
    raw_stream_enabled = false;
}

void Joint_RequestAverageSnapshot(void)
{
    average_snapshot_requested = true;
}

void Joint_RequestCalibrationCheck(void)
{
    mapping_requested = true;
}

void Joint_RequestWearingZeroCalibration(void)
{
    wearing_zero_requested = true;
}

void Joint_RequestAngleStreamStart(void)
{
    angle_snapshot_requested = true;
}

void Joint_RequestAngleStreamStop(void)
{
    angle_snapshot_requested = false;
}

void Joint_RequestTactileStreamStart(void)
{
    tactile_stream_enabled = true;
    continuous_stream_immediate = true;
}

void Joint_RequestTactileStreamStop(void)
{
    tactile_stream_enabled = false;
}

void Joint_APP(void)
{
    u16 all_adc[ADC_LOGICAL_CHANNEL_COUNT];
    u16 tactile[TACTILE_CHANNEL_COUNT];
    TickType_t current_tick;
    bool continuous_stream_due = false;

    if(raw_stream_enabled || tactile_stream_enabled)
    {
        current_tick = xTaskGetTickCount();
        if(continuous_stream_immediate ||
           (current_tick - last_continuous_stream_tick) >=
               pdMS_TO_TICKS(CONTINUOUS_STREAM_PERIOD_MS))
        {
            continuous_stream_due = true;
            continuous_stream_immediate = false;
            last_continuous_stream_tick = current_tick;
        }
    }

    if(average_snapshot_requested)
    {
        average_snapshot_requested = false;
        PrintAverageSnapshot();
        return;
    }

    if(mapping_requested)
    {
        mapping_requested = false;
        PrintMapping();
    }

    /* Stay completely idle until an ADC-dependent operation is requested. */
    if(!wearing_zero_requested &&
       !angle_snapshot_requested &&
       !continuous_stream_due)
    {
        return;
    }

    ADC_ReadAll32(all_adc);

    if(wearing_zero_requested)
    {
        wearing_zero_requested = false;
        CaptureWearingZero(all_adc);
    }

    if(raw_stream_enabled && continuous_stream_due)
    {
        PrintU16Frame("RAW", all_adc, ADC_LOGICAL_CHANNEL_COUNT);
    }

    if(angle_snapshot_requested)
    {
        angle_snapshot_requested = false;
        PrintAngleFrame(all_adc);
    }

    if(tactile_stream_enabled && continuous_stream_due)
    {
        ExtractChannels(all_adc, tactile_adc_number,
                        TACTILE_CHANNEL_COUNT, tactile);
        PrintU16Frame("TAC", tactile, TACTILE_CHANNEL_COUNT);
    }
}
