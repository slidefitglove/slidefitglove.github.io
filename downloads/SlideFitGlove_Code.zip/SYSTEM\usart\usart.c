#include "sys.h"
#include "usart.h"

#pragma import(__use_no_semihosting)

struct __FILE
{
    int handle;
};

FILE __stdout;

void _sys_exit(int x)
{
    (void)x;
}

/* Select the active temporary/normal console at compile time. */
int fputc(int ch, FILE *f)
{
    (void)f;
#if UART1_PA9_PA10_DIAGNOSTIC
    while((USART1->SR & USART_FLAG_TXE) == 0U)
    {
    }
    USART1->DR = (u8)ch;
#else
    while((USART2->SR & USART_FLAG_TXE) == 0U)
    {
    }
    USART2->DR = (u8)ch;
#endif
    return ch;
}

u8 USART_RX_BUF_U1[USART_REC_LEN];
u8 IMU_RX_BUF_U2[IMU_REC_LEN];
u8 DIS_RX_BUF_U3[USART_REC_LEN];
u8 WiFi_RX_BUF_U6[USART_REC_LEN];

volatile u8 uart1_len = 0U;
volatile u8 uart_command_ready = 0U;
volatile u8 imu_len = 0U;
volatile u8 dis_len = 0U;
volatile u8 wifi_len = 0U;
volatile u32 usart2_rx_total_count = 0U;
volatile u32 usart2_rx_error_count = 0U;
volatile u32 uart1_test_rx_count = 0U;
volatile u8 uart1_test_last_byte = 0U;

void uart_init(u32 bound)
{
    GPIO_InitTypeDef gpio;
    USART_InitTypeDef usart;
    NVIC_InitTypeDef nvic;

#if UART1_PA9_PA10_DIAGNOSTIC
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);

    GPIO_PinAFConfig(GPIOA, GPIO_PinSource9, GPIO_AF_USART1);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource10, GPIO_AF_USART1);

    gpio.GPIO_Pin = GPIO_Pin_9 | GPIO_Pin_10;
    gpio.GPIO_Mode = GPIO_Mode_AF;
    gpio.GPIO_Speed = GPIO_Speed_50MHz;
    gpio.GPIO_OType = GPIO_OType_PP;
    gpio.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_Init(GPIOA, &gpio);

    USART_StructInit(&usart);
    usart.USART_BaudRate = bound;
    usart.USART_WordLength = USART_WordLength_8b;
    usart.USART_StopBits = USART_StopBits_1;
    usart.USART_Parity = USART_Parity_No;
    usart.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    usart.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(USART1, &usart);
    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);
    USART_Cmd(USART1, ENABLE);

    nvic.NVIC_IRQChannel = USART1_IRQn;
    nvic.NVIC_IRQChannelPreemptionPriority = 5U;
    nvic.NVIC_IRQChannelSubPriority = 0U;
    nvic.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&nvic);
#else
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
    RCC_APB1PeriphResetCmd(RCC_APB1Periph_USART2, ENABLE);
    RCC_APB1PeriphResetCmd(RCC_APB1Periph_USART2, DISABLE);

    GPIO_PinAFConfig(GPIOD, GPIO_PinSource5, GPIO_AF_USART2);

    gpio.GPIO_Pin = GPIO_Pin_5;
    gpio.GPIO_Mode = GPIO_Mode_AF;
    gpio.GPIO_Speed = GPIO_Speed_50MHz;
    gpio.GPIO_OType = GPIO_OType_PP;
    gpio.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_Init(GPIOD, &gpio);

#if UART_PD6_GPIO_DIAGNOSTIC
    /* Read the CH340N TXD signal directly, without involving USART2 RX. */
    gpio.GPIO_Pin = GPIO_Pin_6;
    gpio.GPIO_Mode = GPIO_Mode_IN;
    gpio.GPIO_Speed = GPIO_Speed_50MHz;
    gpio.GPIO_OType = GPIO_OType_PP;
    gpio.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_Init(GPIOD, &gpio);
#else
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource6, GPIO_AF_USART2);
    gpio.GPIO_Pin = GPIO_Pin_6;
    gpio.GPIO_Mode = GPIO_Mode_AF;
    gpio.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_Init(GPIOD, &gpio);
#endif

    USART_StructInit(&usart);
    usart.USART_BaudRate = bound;
    usart.USART_WordLength = USART_WordLength_8b;
    usart.USART_StopBits = USART_StopBits_1;
    usart.USART_Parity = USART_Parity_No;
    usart.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    usart.USART_Mode = USART_Mode_Tx;
#if !UART_PD6_GPIO_DIAGNOSTIC
    usart.USART_Mode |= USART_Mode_Rx;
#endif
    USART_Init(USART2, &usart);
#if !UART_PD6_GPIO_DIAGNOSTIC
    USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
#endif
    USART_Cmd(USART2, ENABLE);

#if !UART_PD6_GPIO_DIAGNOSTIC
    nvic.NVIC_IRQChannel = USART2_IRQn;
    /* Handler does not call FreeRTOS, so keep it above the RTOS mask level. */
    nvic.NVIC_IRQChannelPreemptionPriority = 4U;
    nvic.NVIC_IRQChannelSubPriority = 0U;
    nvic.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&nvic);
#else
    (void)nvic;
#endif
#endif
}

/* Retained as compatibility stubs for copied application modules. */
void IMU_init(u32 bound)     { (void)bound; }
void Display_init(u32 bound) { (void)bound; }
void WiFi_init(u32 bound)    { (void)bound; }

#if UART1_PA9_PA10_DIAGNOSTIC
void USART1_IRQHandler(void)
{
    u16 status = USART1->SR;

    if((status & USART_SR_RXNE) != 0U)
    {
        uart1_test_last_byte = (u8)USART_ReceiveData(USART1);
        uart1_test_rx_count++;
    }
    else if((status & (USART_SR_ORE | USART_SR_NE | USART_SR_FE)) != 0U)
    {
        (void)USART1->DR;
    }
}
#endif

void USART2_IRQHandler(void)
{
    u8 received;
    u16 status = USART2->SR;

    if((status & (USART_SR_ORE | USART_SR_NE | USART_SR_FE)) != 0U)
    {
        usart2_rx_error_count++;
    }

    if((status & USART_SR_RXNE) != 0U)
    {
        received = (u8)USART_ReceiveData(USART2);
        usart2_rx_total_count++;

        if(received == '\n')
        {
            if(uart1_len > 0U)
            {
                uart_command_ready = 1U;
            }
        }
        else if(received == '\r')
        {
            /* CR is ignored; LF terminates variable-length ASCII commands. */
        }
        else if((received >= 0x20U) && (received <= 0x7EU) &&
                (uart_command_ready == 0U))
        {
            if(uart1_len < (USART_REC_LEN - 1U))
            {
                USART_RX_BUF_U1[uart1_len++] = received;
                USART_RX_BUF_U1[uart1_len] = 0U;
            }
            else
            {
                uart1_len = 0U;
                USART_RX_BUF_U1[0] = 0U;
            }
        }
    }
    else if((status & (USART_SR_ORE | USART_SR_NE | USART_SR_FE)) != 0U)
    {
        /* Reading DR after SR clears ORE/NE/FE when RXNE is not set. */
        (void)USART2->DR;
    }
}

void UartSendDat(USART_TypeDef *uartch, u8 *send_buff, u32 length)
{
    u32 index;

    for(index = 0U; index < length; index++)
    {
        while((uartch->SR & USART_FLAG_TXE) == 0U)
        {
        }
        uartch->DR = send_buff[index];
    }
}
