#include "adc.h"
#include "delay.h"

/* PB7 selects the A/B inputs of all four TMUX1574 devices. */
#define ADC_MUX_GPIO        GPIOB
#define ADC_MUX_PIN         GPIO_Pin_7
#define ADC_EOC_TIMEOUT     100000U

/* Logical sensor number connected to ADC1 hardware channel 0..15. */
static const u8 mux_a_logical_channel[16] =
{
    14, 13, 16, 15, 20, 24, 17, 22,
    26, 25,  1,  2,  3,  8, 28, 27
};

static const u8 mux_b_logical_channel[16] =
{
    10,  9, 12, 11, 19, 23, 18, 21,
    30, 29,  5,  6,  7,  4, 32, 31
};

void Adc_Init(void)
{
    GPIO_InitTypeDef gpio;
    ADC_CommonInitTypeDef common;
    ADC_InitTypeDef adc;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA |
                           RCC_AHB1Periph_GPIOB |
                           RCC_AHB1Periph_GPIOC, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);

    gpio.GPIO_Mode = GPIO_Mode_AN;
    gpio.GPIO_OType = GPIO_OType_PP;
    gpio.GPIO_Speed = GPIO_Speed_50MHz;
    gpio.GPIO_PuPd = GPIO_PuPd_NOPULL;

    gpio.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 |
                    GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7;
    GPIO_Init(GPIOA, &gpio);

    gpio.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;
    GPIO_Init(GPIOB, &gpio);

    gpio.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 |
                    GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5;
    GPIO_Init(GPIOC, &gpio);

    gpio.GPIO_Pin = ADC_MUX_PIN;
    gpio.GPIO_Mode = GPIO_Mode_OUT;
    gpio.GPIO_OType = GPIO_OType_PP;
    gpio.GPIO_Speed = GPIO_Speed_50MHz;
    gpio.GPIO_PuPd = GPIO_PuPd_DOWN;
    GPIO_Init(ADC_MUX_GPIO, &gpio);
    GPIO_ResetBits(ADC_MUX_GPIO, ADC_MUX_PIN);

    RCC_APB2PeriphResetCmd(RCC_APB2Periph_ADC1, ENABLE);
    RCC_APB2PeriphResetCmd(RCC_APB2Periph_ADC1, DISABLE);

    common.ADC_Mode = ADC_Mode_Independent;
    common.ADC_TwoSamplingDelay = ADC_TwoSamplingDelay_5Cycles;
    common.ADC_DMAAccessMode = ADC_DMAAccessMode_Disabled;
    common.ADC_Prescaler = ADC_Prescaler_Div4;
    ADC_CommonInit(&common);

    adc.ADC_Resolution = ADC_Resolution_12b;
    adc.ADC_ScanConvMode = DISABLE;
    adc.ADC_ContinuousConvMode = DISABLE;
    adc.ADC_ExternalTrigConvEdge = ADC_ExternalTrigConvEdge_None;
    adc.ADC_ExternalTrigConv = ADC_ExternalTrigConv_T1_CC1;
    adc.ADC_DataAlign = ADC_DataAlign_Right;
    adc.ADC_NbrOfConversion = 1;
    ADC_Init(ADC1, &adc);
    ADC_Cmd(ADC1, ENABLE);
}

u16 Get_Adc(ADC_TypeDef *ADCx, u8 channel)
{
    u32 timeout = ADC_EOC_TIMEOUT;

    ADC_RegularChannelConfig(ADCx, channel, 1, ADC_SampleTime_480Cycles);
    ADC_ClearFlag(ADCx, ADC_FLAG_EOC);
    ADC_SoftwareStartConv(ADCx);
    while((ADC_GetFlagStatus(ADCx, ADC_FLAG_EOC) == RESET) && (timeout > 0U))
    {
        timeout--;
    }

    if(timeout == 0U)
    {
        return 0U;
    }

    return ADC_GetConversionValue(ADCx);
}

static void ReadMuxBank(BitAction select_b, const u8 *logical_map,
                        u16 values[ADC_LOGICAL_CHANNEL_COUNT])
{
    u8 adc_channel;

    GPIO_WriteBit(ADC_MUX_GPIO, ADC_MUX_PIN, select_b);
    delay_us(50);

    for(adc_channel = 0; adc_channel < 16U; adc_channel++)
    {
        /* Discard the first conversion after changing the ADC input channel. */
        (void)Get_Adc(ADC1, adc_channel);
        values[logical_map[adc_channel] - 1U] = Get_Adc(ADC1, adc_channel);
    }
}

void ADC_ReadAll32(u16 values[ADC_LOGICAL_CHANNEL_COUNT])
{
    ReadMuxBank(Bit_RESET, mux_a_logical_channel, values);
    ReadMuxBank(Bit_SET, mux_b_logical_channel, values);
}
