#include <string.h>
#include <stdbool.h>
#include <stdlib.h>
#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "led.h"
#include "adc.h"
#include "adc_app.h"
#include "kalman.h"

bool ADCCal_Flag = false;
bool ADCNom_Flag = false;
bool RESNom_Flag = false;

u16 adcC1, adcC2, adcC3, adcC4, adcC5, adcC6, adcC7, adcC8, adcC9, adcC10;
u16 adcC11, adcC12, adcC13, adcC14, adcC15, adcC16, adcC17, adcC18, adcC19, adcC20, adcC21;

float angleConvertion(float voltage)
{
	float angle = (voltage / 3.3f) * 320;
	if(angle > 320.0f) angle = 320.0f;
	if(angle < 0.0f) angle = 0.0f;
	return angle;
}

float forceConvertion(float voltage)
{
	float force = (voltage - 35 / 24) * 2400;
	//if(force > 5000.0f) force = 5000.0f;
	if(force < 0.0f) force = 0.0f;
	return force;
}


void ADC_APP(void)
{
		u16 adcx;
		float KalmanValue, Angle, Force, temp;
	

	
	
#if 1
		if(ADCNom_Flag == true)//����ģʽ
		{
			adcx = abs((int)Get_Adc(ADC3, ADC_Channel_9) - (int)adcC1);
			temp = (float) adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(KalmanValue);
//			printf("1��0x%04x\n",Get_Adc(ADC3, ADC_Channel_9));
			printf("%.2f\t",Angle);
			
			adcx = abs((int)Get_Adc(ADC3, ADC_Channel_14) - (int)adcC2);
			temp = (float) adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(KalmanValue);
			printf("%.2f\t",Angle);
			
			adcx = abs((int)Get_Adc(ADC3, ADC_Channel_15) - (int)adcC3);
			temp = (float) adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(KalmanValue);
			printf("%.2f\t",Angle);
			
			adcx = abs((int)Get_Adc(ADC3, ADC_Channel_4) - (int)adcC4);
			temp = (float) adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(KalmanValue);
			printf("%.2f\t",Angle);
			
			adcx = abs((int)Get_Adc(ADC3, ADC_Channel_5) - (int)adcC5);
			temp = (float) adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(KalmanValue);
			printf("%.2f\t",Angle);
			
			adcx = abs((int)Get_Adc(ADC3, ADC_Channel_7) - (int)adcC6);
			temp = (float) adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(KalmanValue);
			printf("%.2f\t",Angle);
			
			adcx = abs((int)Get_Adc(ADC3, ADC_Channel_6) - (int)adcC7);
			temp = (float) adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(KalmanValue);
			printf("%.2f\t",Angle);
					
			adcx = abs((int)Get_Adc(ADC3, ADC_Channel_8) - (int)adcC8);
			temp = (float) adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(KalmanValue);
			printf("%.2f\t",Angle);
			
			adcx = abs((int)Get_Adc(ADC1, ADC_Channel_11) - (int)adcC9);
			temp = (float)adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(Angle);
			printf("%.2f\t",Angle);
			
			adcx = abs((int)Get_Adc(ADC1, ADC_Channel_10) - (int)adcC10);
			temp = (float)adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(KalmanValue);
			printf("%.2f\t",Angle);
			
			adcx = abs((int)Get_Adc(ADC1, ADC_Channel_12) - (int)adcC11);
			temp = (float)adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(KalmanValue);
			printf("%.2f\t",Angle);
			
			adcx = abs((int)Get_Adc(ADC1, ADC_Channel_13) - (int)adcC12);
			temp = (float)adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(KalmanValue);
			printf("%.2f\t",Angle);
			
			adcx = abs((int)Get_Adc(ADC1, ADC_Channel_5) - (int)adcC13);
			temp = (float)adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(KalmanValue);
			printf("%.2f\t",Angle);
			
			adcx = abs((int)Get_Adc(ADC1, ADC_Channel_9) - (int)adcC14);
			temp = (float)adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(KalmanValue);
			printf("%.2f\t",Angle);
			
			adcx = abs((int)Get_Adc(ADC1, ADC_Channel_4) - (int)adcC15);
			temp = (float)adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(KalmanValue);
			printf("%.2f\t",Angle);
				
			adcx = abs((int)Get_Adc(ADC1, ADC_Channel_6) - (int)adcC16);
			temp = (float)adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(KalmanValue);
			printf("%.2f\t",Angle);
		
			adcx = abs((int)Get_Adc(ADC1, ADC_Channel_7) - (int)adcC17);
			temp = (float)adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(KalmanValue);
			printf("%.2f\t",Angle);
			
			adcx = abs((int)Get_Adc(ADC1, ADC_Channel_14) - (int)adcC18);
			temp = (float)adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(KalmanValue);
			printf("%.2f\t",Angle);
			
			adcx = abs((int)Get_Adc(ADC1, ADC_Channel_8) - (int)adcC19);
			temp = (float)adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(KalmanValue);
			printf("%.2f\t",Angle);
								
			adcx = abs((int)Get_Adc(ADC1, ADC_Channel_15) - (int)adcC20);
			temp = (float)adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(KalmanValue);
			printf("%.2f\t",Angle);
			
			printf("\n");
//			ADCNom_Flag = false;
		}
		
		if(ADCCal_Flag == true)//�궨ģʽ
		{
			adcC1 = Get_Adc(ADC3, ADC_Channel_9);//1			
			adcC2 = Get_Adc(ADC3, ADC_Channel_14);
			adcC3 = Get_Adc(ADC3, ADC_Channel_15);
			adcC4 = Get_Adc(ADC3, ADC_Channel_4);
			adcC5 = Get_Adc(ADC3, ADC_Channel_5);
			adcC6 = Get_Adc(ADC3, ADC_Channel_7);
			adcC7 = Get_Adc(ADC3, ADC_Channel_6);
			adcC8 = Get_Adc(ADC3, ADC_Channel_8);
			adcC9 = Get_Adc(ADC1, ADC_Channel_11);
			adcC10 = Get_Adc(ADC1, ADC_Channel_10);
			adcC11 = Get_Adc(ADC1, ADC_Channel_12);
			adcC12 = Get_Adc(ADC1, ADC_Channel_13);
			adcC13 = Get_Adc(ADC1, ADC_Channel_5);
			adcC14 = Get_Adc(ADC1, ADC_Channel_9);
			adcC15 = Get_Adc(ADC1, ADC_Channel_4);
			adcC16 = Get_Adc(ADC1, ADC_Channel_6);
			adcC17 = Get_Adc(ADC1, ADC_Channel_7);
			adcC18 = Get_Adc(ADC1, ADC_Channel_14);
			adcC19 = Get_Adc(ADC1, ADC_Channel_8);
			adcC20 = Get_Adc(ADC1, ADC_Channel_15);
			
			printf("�궨16��������0x%04x,0x%04x,0x%04x,0x%04x,0x%04x,0x%04x,0x%04x,0x%04x,0x%04x,0x%04x,0x%04x,0x%04x,0x%04x,0x%04x,0x%04x,\
							0x%04x,0x%04x,0x%04x,0x%04x,0x%04x\n",adcC1,adcC2,adcC3,adcC4,adcC5,adcC6,adcC7,adcC8,adcC9,adcC10,adcC11,adcC12\
							,adcC13,adcC14,adcC15,adcC16,adcC17,adcC18,adcC19,adcC20);
			ADCCal_Flag = false;
		}
#endif	
		if(RESNom_Flag == true)//ѹ������������ģʽ
		{
			adcx = Get_Adc(ADC3, ADC_Channel_9);
			temp =  (float) adcx / 1000;
			KalmanValue = Kalman_Update(&kalman, temp);
			Force = forceConvertion(KalmanValue);
			printf("1��0x%04x\n",adcx);
			printf("1��%.2fg\n",Force);
			
			adcx = abs((int)Get_Adc(ADC3, ADC_Channel_14) - (int)adcC2);
			temp = (float) adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(KalmanValue);
			printf("2��%.2f\n",Angle);
			
			adcx = abs((int)Get_Adc(ADC3, ADC_Channel_15) - (int)adcC3);
			temp = (float) adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(KalmanValue);
			printf("3��%.2f\n",Angle);
			
			adcx = abs((int)Get_Adc(ADC3, ADC_Channel_4) - (int)adcC4);
			temp = (float) adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(KalmanValue);
			printf("4��%.2f\n",Angle);
			
			adcx = abs((int)Get_Adc(ADC3, ADC_Channel_5) - (int)adcC5);
			temp = (float) adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(KalmanValue);
			printf("5��%.2f\n",Angle);
			
			adcx = abs((int)Get_Adc(ADC3, ADC_Channel_7) - (int)adcC6);
			temp = (float) adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(KalmanValue);
			printf("6��%.2f\n",Angle);
			
			adcx = abs((int)Get_Adc(ADC3, ADC_Channel_6) - (int)adcC7);
			temp = (float) adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(KalmanValue);
			printf("7��%.2f\n",Angle);
					
			adcx = abs((int)Get_Adc(ADC3, ADC_Channel_8) - (int)adcC8);
			temp = (float) adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(KalmanValue);
			printf("8��%.2f\n",Angle);
			
			adcx = abs((int)Get_Adc(ADC1, ADC_Channel_11) - (int)adcC9);
			temp = (float)adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(Angle);
			printf("9��%.2f\n",Angle);
			
			adcx = abs((int)Get_Adc(ADC1, ADC_Channel_10) - (int)adcC10);
			temp = (float)adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(KalmanValue);
			printf("10��%.2f\n",Angle);
			
			adcx = abs((int)Get_Adc(ADC1, ADC_Channel_12) - (int)adcC11);
			temp = (float)adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(KalmanValue);
			printf("11��%.2f\n",Angle);
			
			adcx = abs((int)Get_Adc(ADC1, ADC_Channel_13) - (int)adcC12);
			temp = (float)adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(KalmanValue);
			printf("12��%.2f\n",Angle);
			
			adcx = abs((int)Get_Adc(ADC1, ADC_Channel_5) - (int)adcC13);
			temp = (float)adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(KalmanValue);
			printf("13��%.2f\n",Angle);
			
			adcx = abs((int)Get_Adc(ADC1, ADC_Channel_9) - (int)adcC14);
			temp = (float)adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(KalmanValue);
			printf("14��%.2f\n",Angle);
			
			adcx = abs((int)Get_Adc(ADC1, ADC_Channel_4) - (int)adcC15);
			temp = (float)adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(KalmanValue);
			printf("15��%.2f\n",Angle);
				
			adcx = abs((int)Get_Adc(ADC1, ADC_Channel_6) - (int)adcC16);
			temp = (float)adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(KalmanValue);
			printf("16��%.2f\n",Angle);
		
			adcx = abs((int)Get_Adc(ADC1, ADC_Channel_7) - (int)adcC17);
			temp = (float)adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(KalmanValue);
			printf("17��%.2f\n",Angle);
			
			adcx = abs((int)Get_Adc(ADC1, ADC_Channel_14) - (int)adcC18);
			temp = (float)adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(KalmanValue);
			printf("18��%.2f\n",Angle);
			
			adcx = abs((int)Get_Adc(ADC1, ADC_Channel_8) - (int)adcC19);
			temp = (float)adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(KalmanValue);
			printf("19��%.2f\n",Angle);
								
			adcx = abs((int)Get_Adc(ADC1, ADC_Channel_15) - (int)adcC20);
			temp = (float)adcx * (3.3f / 4096);
			KalmanValue = Kalman_Update(&kalman, temp);
			Angle = angleConvertion(KalmanValue);
			printf("20��%.2f\n",Angle);
			
			//RESNom_Flag = false;
		}
}
