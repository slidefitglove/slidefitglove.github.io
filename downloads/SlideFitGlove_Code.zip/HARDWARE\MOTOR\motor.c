#include "motor.h"
#include "stm32f4xx_tim.h"

#define MOTOR_PWM_PERIOD 8162U /* 2 MHz / 8163 = 245.0 Hz */
#define TIM1_PRESCALER   83U   /* 168 MHz / 84 = 2 MHz */
#define TIM2_PRESCALER   41U   /*  84 MHz / 42 = 2 MHz */

static u16 DutyToCompare(u16 period, u8 duty_percent)
{
    if(duty_percent > 100U) duty_percent = 100U;
    return (u16)(((u32)(period + 1U) * duty_percent) / 100U);
}

void Motor_Init(void)
{
    GPIO_InitTypeDef gpio;
    TIM_TimeBaseInitTypeDef time_base;
    TIM_OCInitTypeDef output_compare;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE |
                           RCC_AHB1Periph_GPIOB, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);

    GPIO_PinAFConfig(GPIOE, GPIO_PinSource9, GPIO_AF_TIM1);
    GPIO_PinAFConfig(GPIOE, GPIO_PinSource11, GPIO_AF_TIM1);
    GPIO_PinAFConfig(GPIOE, GPIO_PinSource13, GPIO_AF_TIM1);
    GPIO_PinAFConfig(GPIOE, GPIO_PinSource14, GPIO_AF_TIM1);
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource10, GPIO_AF_TIM2);

    gpio.GPIO_Mode = GPIO_Mode_AF;
    gpio.GPIO_OType = GPIO_OType_PP;
    gpio.GPIO_PuPd = GPIO_PuPd_DOWN;
    gpio.GPIO_Speed = GPIO_Speed_100MHz;
    gpio.GPIO_Pin = GPIO_Pin_9 | GPIO_Pin_11 | GPIO_Pin_13 | GPIO_Pin_14;
    GPIO_Init(GPIOE, &gpio);
    gpio.GPIO_Pin = GPIO_Pin_10;
    GPIO_Init(GPIOB, &gpio);

    TIM_TimeBaseStructInit(&time_base);
    time_base.TIM_Prescaler = TIM1_PRESCALER;
    time_base.TIM_CounterMode = TIM_CounterMode_Up;
    time_base.TIM_ClockDivision = TIM_CKD_DIV1;
    time_base.TIM_RepetitionCounter = 0U;
    time_base.TIM_Period = MOTOR_PWM_PERIOD;
    TIM_TimeBaseInit(TIM1, &time_base);

    TIM_OCStructInit(&output_compare);
    output_compare.TIM_OCMode = TIM_OCMode_PWM1;
    output_compare.TIM_OutputState = TIM_OutputState_Enable;
    output_compare.TIM_OutputNState = TIM_OutputNState_Disable;
    output_compare.TIM_OCPolarity = TIM_OCPolarity_High;
    output_compare.TIM_Pulse = 0U;
    TIM_OC1Init(TIM1, &output_compare);
    TIM_OC2Init(TIM1, &output_compare);
    TIM_OC3Init(TIM1, &output_compare);
    TIM_OC4Init(TIM1, &output_compare);
    TIM_OC1PreloadConfig(TIM1, TIM_OCPreload_Enable);
    TIM_OC2PreloadConfig(TIM1, TIM_OCPreload_Enable);
    TIM_OC3PreloadConfig(TIM1, TIM_OCPreload_Enable);
    TIM_OC4PreloadConfig(TIM1, TIM_OCPreload_Enable);
    TIM_ARRPreloadConfig(TIM1, ENABLE);
    TIM_CtrlPWMOutputs(TIM1, ENABLE);
    TIM_Cmd(TIM1, ENABLE);

    time_base.TIM_Prescaler = TIM2_PRESCALER;
    time_base.TIM_Period = MOTOR_PWM_PERIOD;
    TIM_TimeBaseInit(TIM2, &time_base);
    TIM_OC3Init(TIM2, &output_compare);
    TIM_OC3PreloadConfig(TIM2, TIM_OCPreload_Enable);
    TIM_ARRPreloadConfig(TIM2, ENABLE);
    TIM_Cmd(TIM2, ENABLE);

    /* Motors stay off until an explicit serial command is received. */
    Motor_AllSetDuty(0U);
}

void Motor_SetDuty(u8 motor_number, u8 duty_percent)
{
    u16 compare_tim1 = DutyToCompare(MOTOR_PWM_PERIOD, duty_percent);
    u16 compare_tim2 = DutyToCompare(MOTOR_PWM_PERIOD, duty_percent);

    switch(motor_number)
    {
        case 1U: TIM_SetCompare1(TIM1, compare_tim1); break;
        case 2U: TIM_SetCompare2(TIM1, compare_tim1); break;
        case 3U: TIM_SetCompare3(TIM1, compare_tim1); break;
        case 4U: TIM_SetCompare4(TIM1, compare_tim1); break;
        case 5U: TIM_SetCompare3(TIM2, compare_tim2); break;
        default: break;
    }
}

void Motor_AllSetDuty(u8 duty_percent)
{
    u8 motor;

    for(motor = 1U; motor <= MOTOR_COUNT; motor++)
    {
        Motor_SetDuty(motor, duty_percent);
    }
}
