# glove_1.1 firmware notes

## Hardware assignment

- Posture inputs (21): ADC1-ADC11, ADC13-ADC16, ADC25-ADC28, ADC31-ADC32.
- Tactile inputs (11): ADC12, ADC17-ADC24, ADC29-ADC30.
- TMUX1574 common select: PB7 (`MCU_CTRL`).
- USB serial: USART2 on PD5/PD6 through CH340N, 115200-8-N-1.
- Motor PWM: PE9/TIM1_CH1, PE11/TIM1_CH2, PE13/TIM1_CH3,
  PE14/TIM1_CH4 and PB10/TIM2_CH3. PWM frequency is 245 Hz.

## Angle output and calibration

The firmware stays silent after reset. Every `ANGN` command produces exactly one
frame (it does not enable continuous transmission):

`ANG,<21 calibrated angle values>`

The command service loop runs every 1 ms. ANGN has no configured output-rate
limit: every accepted request produces one response as soon as ADC acquisition
and UART transmission permit. This is independent from the 20 Hz RAW/TAC
diagnostic stream pacing. The host chooses its own requested angle rate.

The 21 values use this fixed order:

1. Index finger: DIP, PIP, MCP, side swing.
2. Middle finger: DIP, PIP, MCP, side swing.
3. Ring finger: DIP, PIP, MCP, side swing.
4. Little finger: DIP, PIP, MCP, side swing.
5. Thumb: IP, MCP, joint 3, joint 4, side swing.

The ADC order is:

`13,9,14,16,1,5,10,31,28,4,3,32,26,25,27,11,8,2,6,7,15`

Middle-finger side swing uses ADC31/CN37 and ring-finger side swing uses
ADC32/CN38. ADC19/CN24 and ADC20/CN25 are no longer used for posture and are
listed only in the optional tactile diagnostic mapping.

The zero/reference pairs in the user's calibration table are used only to
calculate each channel's slope. They are not used as the assembled glove's
runtime zero. Before a successful `WZER`, every angle is reported as 0.00.
`WZER` captures the current 21 ADC samples as the actual per-wearer baseline;
the calibrated slopes remain unchanged. Flexion joints are clamped to 0..90
degrees. Side-swing joints are clamped to -30..+30 degrees, where positive is
left and negative is right.

Thumb ADC7 (serial value 20) is a normal unsigned flexion joint. It uses its
`WZER` sample as 0 degrees and retains the calibrated ADC3200-to-ADC2080 slope.
Its assembled direction is inverted relative to the original calibration:
increasing ADC while rotating downward increases the reported angle from 0 to
90 degrees. Its output is clamped to 0..90 degrees.

## Four-byte serial commands

- `ANGN`: request one 21-channel calibrated-angle frame.
- `ANGS`: cancel a pending angle request (kept for compatibility).
- `TACN` / `TACS`: start / stop the 11-channel tactile raw-ADC stream.
- `CALN` / `CALS`: start / stop the complete 32-channel raw-ADC stream.
- `CAVG`: print a 32-sample averaged snapshot of all 32 ADC inputs.
- `CCHK`: print the posture/tactile logical ADC mapping.
- `WZER`: capture the current 21 posture inputs as the wearing zero.
- `MALL` / `MOFF`: set all five motors to rated drive / off.
- `M1ON` ... `M5ON`: set one motor to rated drive.
- `M1OF` ... `M5OF`: stop one motor.
- `M1V0` ... `M5V0`: stop one motor using the level-control format.
- `M1V1` ... `M5V9`: set one motor to level 1 ... 9.
- `M1VA` ... `M5VA`: set one motor to level 10 (rated maximum).

Legacy commands are exactly four alphanumeric bytes; CR/LF may follow them.
All five motors stay off after reset. Motor levels 1 ... 10 map to 4% ... 40%
duty. The maximum remains limited to 40% at 245 Hz. With the measured 1.9 V
motor rail, level 10 is approximately 1.20 V RMS.
The PCB is a unipolar low-side MOSFET driver, so it cannot generate a true
bipolar AC waveform.

## Teleoperation motor percentage commands

Send a printable ASCII line terminated by LF (`0x0A`):

- `M1 0` through `M5 0`: stop the selected motor.
- `M1 1` through `M5 100`: set the selected motor to 1..100% safe intensity.
- `MOTOR1 0` through `MOTOR5 100`: equivalent long form.

The visible 0..100% value is a normalized safe intensity. Firmware maps 100%
to the board's existing safe maximum of 40% PWM duty at 245 Hz; it never maps
100% intensity to 100% electrical duty. Examples:

- `M1 0\n` hex: `4D 31 20 30 0A`
- `M2 20\n` hex: `4D 32 20 32 30 0A`
- `M5 100\n` hex: `4D 35 20 31 30 30 0A`

## Build output

Open `USER/glove_1.0.uvprojx` in Keil MDK. The verified firmware image is
`OBJ/glove_1_0.hex`.
