#ifndef __JOINT_APP_H
#define __JOINT_APP_H

#include "sys.h"

#define POSTURE_CHANNEL_COUNT 21U
#define TACTILE_CHANNEL_COUNT 11U

void Joint_APP(void);
void Joint_RequestCalibrationStreamStart(void);
void Joint_RequestCalibrationStreamStop(void);
void Joint_RequestAverageSnapshot(void);
void Joint_RequestCalibrationCheck(void);
void Joint_RequestWearingZeroCalibration(void);
void Joint_RequestAngleStreamStart(void);
void Joint_RequestAngleStreamStop(void);
void Joint_RequestTactileStreamStart(void);
void Joint_RequestTactileStreamStop(void);

#endif
