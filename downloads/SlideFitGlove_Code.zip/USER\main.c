#include "sys.h"
#include "delay.h"
#include "FreeRTOS.h"
#include "task.h"
#include "usart.h"
#include "adc.h"
#include "motor.h"
#include "UART_app.h"
#include "joint_app.h"

/*
 * Service incoming commands independently from the requested data rate.
 * A 1 ms service period prevents 30 Hz ANGN commands from accumulating in
 * the single UART receive buffer. Continuous diagnostic streams are paced
 * separately in joint_app.c.
 */
#define GLOVE_COMMAND_SERVICE_PERIOD_MS 1U

#if UART1_PA9_PA10_DIAGNOSTIC
static void Uart1DiagnosticTask(void *parameters)
{
    u32 tx_count = 0U;

    (void)parameters;
    while(1)
    {
        printf("UART1TEST,TX=%lu,RX=%lu,LAST=0x%02X\r\n",
               (unsigned long)tx_count++,
               (unsigned long)uart1_test_rx_count,
               (unsigned int)uart1_test_last_byte);
        vTaskDelay(pdMS_TO_TICKS(500U));
    }
}
#elif UART2_CH340_DIAGNOSTIC
static void Uart2Ch340DiagnosticTask(void *parameters)
{
    u32 tx_count = 0U;

    (void)parameters;
    while(1)
    {
        printf("UART2TEST,TX=%lu,RX=%lu,ERR=%lu,SR=0x%04X,LEN=%u\r\n",
               (unsigned long)tx_count++,
               (unsigned long)usart2_rx_total_count,
               (unsigned long)usart2_rx_error_count,
               (unsigned int)USART2->SR,
               (unsigned int)uart1_len);
        vTaskDelay(pdMS_TO_TICKS(500U));
    }
}
#elif UART_PD6_GPIO_DIAGNOSTIC
#define PD6_DIAGNOSTIC_SAMPLE_COUNT 20000000UL

static void UartPd6DiagnosticTask(void *parameters)
{
    u32 sample;
    u32 low_samples;
    u32 falling_edges;
    u32 current_low_run;
    u32 longest_low_run;
    u32 previous_high;
    u32 current_high;

    (void)parameters;
    printf("PD6TEST,START,USART2_RX_DISABLED,PD6_GPIO_INPUT\r\n");

    while(1)
    {
        low_samples = 0U;
        falling_edges = 0U;
        current_low_run = 0U;
        longest_low_run = 0U;
        previous_high = ((GPIOD->IDR & GPIO_Pin_6) != 0U) ? 1U : 0U;

        for(sample = 0U; sample < PD6_DIAGNOSTIC_SAMPLE_COUNT; sample++)
        {
            current_high = ((GPIOD->IDR & GPIO_Pin_6) != 0U) ? 1U : 0U;
            if(current_high == 0U)
            {
                low_samples++;
                current_low_run++;
                if(current_low_run > longest_low_run)
                {
                    longest_low_run = current_low_run;
                }
            }
            else
            {
                current_low_run = 0U;
            }

            if((previous_high != 0U) && (current_high == 0U))
            {
                falling_edges++;
            }
            previous_high = current_high;
        }

        printf("PD6TEST,LOW=%lu,FALL=%lu,LONGEST=%lu,FINAL=%s\r\n",
               (unsigned long)low_samples,
               (unsigned long)falling_edges,
               (unsigned long)longest_low_run,
               ((GPIOD->IDR & GPIO_Pin_6) != 0U) ? "HIGH" : "LOW");
        vTaskDelay(pdMS_TO_TICKS(200U));
    }
}
#else
static void GloveSampleTask(void *parameters)
{
    (void)parameters;
    while(1)
    {
        UART_APP();
        Joint_APP();
        vTaskDelay(pdMS_TO_TICKS(GLOVE_COMMAND_SERVICE_PERIOD_MS));
    }
}
#endif

int main(void)
{
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);
    delay_init(168U);
    uart_init(115200U);
#if !UART1_PA9_PA10_DIAGNOSTIC && !UART2_CH340_DIAGNOSTIC
    Adc_Init();
    Motor_Init();
#endif

#if UART1_PA9_PA10_DIAGNOSTIC
    xTaskCreate(Uart1DiagnosticTask, "UART1TEST", configMINIMAL_STACK_SIZE * 3U,
                NULL, 2U, NULL);
#elif UART2_CH340_DIAGNOSTIC
    xTaskCreate(Uart2Ch340DiagnosticTask, "UART2TEST", configMINIMAL_STACK_SIZE * 3U,
                NULL, 2U, NULL);
#elif UART_PD6_GPIO_DIAGNOSTIC
    xTaskCreate(UartPd6DiagnosticTask, "PD6TEST", configMINIMAL_STACK_SIZE * 3U,
                NULL, 2U, NULL);
#else
    xTaskCreate(GloveSampleTask, "GLOVE", configMINIMAL_STACK_SIZE * 3U,
                NULL, 2U, NULL);
#endif

    vTaskStartScheduler();

    while(1)
    {
    }
}
