#ifndef __UART_APP_H
#define __UART_APP_H

#include "sys.h"

void UART_APP(void);

#endif
