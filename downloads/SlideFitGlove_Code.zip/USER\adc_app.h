#ifndef __ADC_APP_H
#define __ADC_APP_H	
#include "sys.h" 
#include <string.h>
#include <stdbool.h>
 							   
void ADC_APP(void);

extern bool ADCCal_Flag;
extern bool ADCNom_Flag;
extern bool RESNom_Flag;
#endif 
