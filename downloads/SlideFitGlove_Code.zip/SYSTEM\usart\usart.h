#ifndef __USART_H
#define __USART_H

#include "stdio.h"
#include "stm32f4xx_conf.h"
#include "sys.h"

#define USART_REC_LEN 200U
#define IMU_REC_LEN   204U

/* Set to 1 only for temporary CH340N TXD/PD6 electrical diagnostics. */
#define UART_PD6_GPIO_DIAGNOSTIC 0U

/* Temporary DAP virtual-COM test on the routed USART1 pins PA9/PA10. */
#define UART1_PA9_PA10_DIAGNOSTIC 0U

/* Temporary minimal test of the onboard CH340N on USART2 PD5/PD6. */
#define UART2_CH340_DIAGNOSTIC 0U

extern u8 USART_RX_BUF_U1[USART_REC_LEN];
extern u8 IMU_RX_BUF_U2[IMU_REC_LEN];
extern u8 DIS_RX_BUF_U3[USART_REC_LEN];
extern u8 WiFi_RX_BUF_U6[USART_REC_LEN];
extern volatile u8 uart1_len;
extern volatile u8 uart_command_ready;
extern volatile u8 imu_len;
extern volatile u8 dis_len;
extern volatile u8 wifi_len;
extern volatile u32 usart2_rx_total_count;
extern volatile u32 usart2_rx_error_count;
extern volatile u32 uart1_test_rx_count;
extern volatile u8 uart1_test_last_byte;

void uart_init(u32 bound);
void IMU_init(u32 bound);
void Display_init(u32 bound);
void WiFi_init(u32 bound);
void UartSendDat(USART_TypeDef *uartch, u8 *send_buff, u32 length);

#endif
