#include <string.h>
#include <stdbool.h>
#include "sys.h"
#include "usart.h"
#include "joint_app.h"
#include "motor.h"
#include "UART_app.h"

static bool CommandIs(const char text[4])
{
    return (uart1_len == 4U &&
            USART_RX_BUF_U1[0] == (u8)text[0] &&
            USART_RX_BUF_U1[1] == (u8)text[1] &&
            USART_RX_BUF_U1[2] == (u8)text[2] &&
            USART_RX_BUF_U1[3] == (u8)text[3]);
}

static u8 MotorPercentToDuty(u8 percent)
{
    if(percent > 100U) percent = 100U;
    return (u8)(((u16)MOTOR_RATED_DUTY_PERCENT * percent + 50U) / 100U);
}

static bool ParseMotorPercent(u8 *motor, u8 *percent)
{
    u8 index;
    u16 value = 0U;
    bool has_digit = false;

    if(uart_command_ready == 0U) return false;

    if(uart1_len >= 4U && USART_RX_BUF_U1[0] == 'M' &&
       USART_RX_BUF_U1[1] >= '1' && USART_RX_BUF_U1[1] <= '5')
    {
        *motor = (u8)(USART_RX_BUF_U1[1] - '0');
        index = 2U;
    }
    else if(uart1_len >= 8U &&
            USART_RX_BUF_U1[0] == 'M' && USART_RX_BUF_U1[1] == 'O' &&
            USART_RX_BUF_U1[2] == 'T' && USART_RX_BUF_U1[3] == 'O' &&
            USART_RX_BUF_U1[4] == 'R' &&
            USART_RX_BUF_U1[5] >= '1' && USART_RX_BUF_U1[5] <= '5')
    {
        *motor = (u8)(USART_RX_BUF_U1[5] - '0');
        index = 6U;
    }
    else
    {
        return false;
    }

    while(index < uart1_len && USART_RX_BUF_U1[index] == ' ') index++;
    while(index < uart1_len)
    {
        u8 character = USART_RX_BUF_U1[index++];
        if(character < '0' || character > '9') return false;
        has_digit = true;
        value = (u16)(value * 10U + (u16)(character - '0'));
        if(value > 100U) return false;
    }

    if(!has_digit) return false;
    *percent = (u8)value;
    return true;
}

static void ClearCommandBuffer(void)
{
    USART_ITConfig(USART2, USART_IT_RXNE, DISABLE);
    memset(USART_RX_BUF_U1, 0, USART_REC_LEN);
    uart1_len = 0U;
    uart_command_ready = 0U;
    USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
}

void UART_APP(void)
{
    u8 motor;
    u8 percent;
    u8 duty;

    if(uart1_len == 0U) return;
    if(uart_command_ready == 0U && uart1_len != 4U) return;
    if(uart_command_ready == 0U && uart1_len == 4U &&
       USART_RX_BUF_U1[0] == 'M' && USART_RX_BUF_U1[2] == ' ')
    {
        return;
    }
    if(uart_command_ready == 0U && uart1_len == 4U &&
       USART_RX_BUF_U1[0] == 'M' && USART_RX_BUF_U1[1] == 'O' &&
       USART_RX_BUF_U1[2] == 'T' && USART_RX_BUF_U1[3] == 'O')
    {
        return;
    }

    if(ParseMotorPercent(&motor, &percent))
    {
        duty = MotorPercentToDuty(percent);
        Motor_SetDuty(motor, duty);
        printf("MOTOR,%u,PERCENT=%u,DUTY=%u,FREQ=245HZ\r\n",
               (unsigned int)motor,
               (unsigned int)percent,
               (unsigned int)duty);
    }
    else if(CommandIs("ANGN"))
    {
        Joint_RequestAngleStreamStart();
    }
    else if(CommandIs("ANGS"))
    {
        Joint_RequestAngleStreamStop();
        printf("ANGS,OK\r\n");
    }
    else if(CommandIs("TACN"))
    {
        Joint_RequestTactileStreamStart();
        printf("TACN,OK,RATE=20HZ,CHANNELS=11\r\n");
    }
    else if(CommandIs("TACS"))
    {
        Joint_RequestTactileStreamStop();
        printf("TACS,OK\r\n");
    }
    else if(CommandIs("CALN"))
    {
        Joint_RequestCalibrationStreamStart();
        printf("CALN,OK,RATE=20HZ,CHANNELS=32\r\n");
    }
    else if(CommandIs("CALS"))
    {
        Joint_RequestCalibrationStreamStop();
        printf("CALS,OK\r\n");
    }
    else if(CommandIs("CAVG"))
    {
        Joint_RequestAverageSnapshot();
    }
    else if(CommandIs("CCHK"))
    {
        Joint_RequestCalibrationCheck();
    }
    else if(CommandIs("WZER"))
    {
        Joint_RequestWearingZeroCalibration();
    }
    else if(CommandIs("MALL"))
    {
        Motor_AllSetDuty(MOTOR_RATED_DUTY_PERCENT);
        printf("MALL,OK,FREQ=245HZ,DUTY=%u\r\n",
               (unsigned int)MOTOR_RATED_DUTY_PERCENT);
    }
    else if(CommandIs("MOFF"))
    {
        Motor_AllSetDuty(0U);
        printf("MOFF,OK\r\n");
    }
    else
    {
        bool motor_command_matched = false;

        for(motor = 1U; motor <= MOTOR_COUNT; motor++)
        {
            if(USART_RX_BUF_U1[0] == 'M' &&
               USART_RX_BUF_U1[1] == (u8)('0' + motor) &&
               USART_RX_BUF_U1[2] == 'V' &&
               ((USART_RX_BUF_U1[3] >= '0' && USART_RX_BUF_U1[3] <= '9') ||
                USART_RX_BUF_U1[3] == 'A'))
            {
                u8 level = (USART_RX_BUF_U1[3] == 'A') ? 10U :
                           (u8)(USART_RX_BUF_U1[3] - '0');
                u8 legacy_duty = MotorPercentToDuty((u8)(level * 10U));

                Motor_SetDuty(motor, legacy_duty);
                printf("M%uV%c,OK,LEVEL=%u,DUTY=%u,FREQ=245HZ\r\n",
                       (unsigned int)motor,
                       USART_RX_BUF_U1[3],
                       (unsigned int)level,
                       (unsigned int)legacy_duty);
                motor_command_matched = true;
                break;
            }

            if(USART_RX_BUF_U1[0] == 'M' &&
               USART_RX_BUF_U1[1] == (u8)('0' + motor) &&
               USART_RX_BUF_U1[2] == 'O' &&
               USART_RX_BUF_U1[3] == 'N')
            {
                Motor_SetDuty(motor, MOTOR_RATED_DUTY_PERCENT);
                printf("M%uON,OK,FREQ=245HZ,DUTY=%u\r\n",
                       (unsigned int)motor,
                       (unsigned int)MOTOR_RATED_DUTY_PERCENT);
                motor_command_matched = true;
                break;
            }
            if(USART_RX_BUF_U1[0] == 'M' &&
               USART_RX_BUF_U1[1] == (u8)('0' + motor) &&
               USART_RX_BUF_U1[2] == 'O' &&
               USART_RX_BUF_U1[3] == 'F')
            {
                Motor_SetDuty(motor, 0U);
                printf("M%uOF,OK\r\n", (unsigned int)motor);
                motor_command_matched = true;
                break;
            }
        }

        if(!motor_command_matched)
        {
            printf("CMD,ERROR,%s\r\n", USART_RX_BUF_U1);
        }
    }

    ClearCommandBuffer();
}
