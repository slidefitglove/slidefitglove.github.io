#ifndef __IMU_APP_H
#define __IMU_APP_H	
#include <stdbool.h>
#include "sys.h" 

typedef enum 
{
		originalADC 		 = 0x00,//ԭʼadc
		calculatingAngle = 0x01,//������̬��
		bothData 				 = 0x02 //ȫ��֧��
}dataType;

typedef enum 
{
		frame_10 	= 0x00,//
		frame_20  = 0x01,//
		frame_50 	= 0x02, //
		frame_70  = 0x03,
		frame_100 = 0x04
}updateSpeed;

typedef enum 
{
		bound2400 	= 0x00,//
		bound4800   = 0x01,//
		bound9600 	= 0x02, //
		bound14400  = 0x03,
		bound19200  = 0x04,
		bound38400  = 0x05,
		bound56000  = 0x06,
		bound115200 = 0x07
}boundSet;

extern u32 pitchAngle;//������
extern u32 rollAngle;//�����
extern u32 tiltAngle;//��б��
extern u16 calFrequency;//��������

extern bool imuAttitudeFlag;

extern float pitch;
extern float roll;
extern float tilt;

void IMU_APP(void);
void IMU_initSet(dataType type, u8 speed, u32 bound);
#endif 
