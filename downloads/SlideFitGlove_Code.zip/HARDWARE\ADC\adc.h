#ifndef __ADC_H
#define __ADC_H

#include "sys.h"

#define ADC_LOGICAL_CHANNEL_COUNT 32U

void Adc_Init(void);
u16 Get_Adc(ADC_TypeDef *ADCx, u8 channel);
void ADC_ReadAll32(u16 values[ADC_LOGICAL_CHANNEL_COUNT]);

#endif
